﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace ConTestODBC
{
    public  class CommonUtils
    {
        /// <summary>
        /// 将单个单词首字母大写
        /// </summary>
        /// <param name="sType"></param>
        /// <returns></returns>
        public static string FirstToUpper(string sType)
        {
            string result = "";
            result = sType.Substring(0, 1).ToUpper() + sType.Substring(1);
            //.Substring(0, 1).ToUpper()把循环到的字符串第一个字母截取并转换为大写
            //并用s.Substring(1)得到循环到的字符串除第一个字符后的所有字符拼装到首字母后面。
            return result;
        }
        /// <summary>
        /// 将一句话的每个单词首字母大写
        /// </summary>
        /// <param name="sWord"></param>
        /// <returns></returns>
        public static string FirstAllToUpper(string sWord)
        {
            string[] strArray = sWord.Split(' ');
            string result = "";//定义一个空字符串
            foreach (string c in strArray)//循环处理数组里面每一个字符串
            {
                result += c.Substring(0, 1).ToUpper() + c.Substring(1) + " ";
                //.Substring(0, 1).ToUpper()把循环到的字符串第一个字母截取并转换为大写
                //并用s.Substring(1)得到循环到的字符串除第一个字符后的所有字符拼装到首字母后面。
            }
            Console.WriteLine(result);
            return result;
        }

        public static string FiledFirstToUpper(string sWord)
        {
            string[] strArray = sWord.Split('_');
            string result = "";//定义一个空字符串
            foreach (string c in strArray)//循环处理数组里面每一个字符串
            {
                result += c.Substring(0, 1).ToUpper() + c.Substring(1);
                //.Substring(0, 1).ToUpper()把循环到的字符串第一个字母截取并转换为大写
                //并用s.Substring(1)得到循环到的字符串除第一个字符后的所有字符拼装到首字母后面。
            }
            Console.WriteLine(result);
            return result;
        }

        public static string CreateMethodName(string sWord)
        {
            string[] strArray = sWord.Split('_');
            string result = "";//定义一个空字符串
            foreach (string c in strArray)//循环处理数组里面每一个字符串
            {
                if (strArray.Contains("View"))
                {
                    if (c != "View")
                    {
                        result += c.Substring(0, 1).ToUpper() + c.Substring(1);
                    }
                }
                if (strArray.Contains("Update"))
                {
                    if (c != "Update")
                    {
                        result += c.Substring(0, 1).ToUpper() + c.Substring(1);
                    }
                }
                //.Substring(0, 1).ToUpper()把循环到的字符串第一个字母截取并转换为大写
                //并用s.Substring(1)得到循环到的字符串除第一个字符后的所有字符拼装到首字母后面。
            }
            if (strArray.Contains("View"))
            {
                result = "View" + result;
            }
            if (strArray.Contains("Update"))
            {
                result = "Update" + result;
            }
            Console.WriteLine(result);
            return result;
        }
        /// <summary>
        /// 获取加密后的数据
        /// </summary>
        /// <param name="aStrString"></param>
        /// <returns></returns>
        public static string getPwdEncrypt(string aStrString)
        {
            try
            {

                var des = new TripleDESCryptoServiceProvider
                {
                    Key = Convert.FromBase64String("DrZPGgL9WHkZrVQ0DT2bASoZE0Z8oc4s"),
                    Mode = CipherMode.ECB
                };
                var desEncrypt = des.CreateEncryptor();
                var key = des.Key;
                byte[] buffer = Encoding.UTF8.GetBytes(aStrString);
                return Convert.ToBase64String(desEncrypt.TransformFinalBlock(buffer, 0, buffer.Length));
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}
