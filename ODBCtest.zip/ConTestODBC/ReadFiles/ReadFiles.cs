﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConTestODBC
{
    public  class ReadFiles
    {
        /// <summary>
        /// 用于生成翻译
        /// </summary>
        /// <returns></returns>
        public static string[] ReadInText()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InEnglishText.txt", Encoding.UTF8);
            string[] arrayInFields = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayInFields;
        }
        /// <summary>
        /// 读取中文文档时必须先修改文档编码
        /// </summary>
        /// <returns></returns>
        public static string[] ReadChineseText()
        {
            string[] arrayOutFields;
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InChineseText.txt", Encoding.UTF8);//与文档编码不一致时会乱码

            arrayOutFields = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);

            return arrayOutFields;
        }
       //===================用于生成测试数据
       /// <summary>
       /// 
       /// </summary>
       /// <returns></returns>
        public static string[] ReadTime()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\TimeText.txt");
            string[] arrayMat = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayMat;
        }
        public static string[] ReadMat()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\MatText.txt");
            string[] arrayMat = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayMat;
        }
        public static string[] ReadRes()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\ResText.txt");
            string[] arrayMat = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayMat;
        }
        public static string[] ReadInTestData()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\TestDataText.txt");
            string[] aTestData = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return aTestData;
        }
        public static string[] ReadInTestType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\TestTypeText.txt");
            string[] aTestData = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return aTestData;
        }
        public static string[] ReadInTestStep()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\TestStepText.txt");
            string[] aTestData = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return aTestData;
        }
        public static string[] ReadInTestOper()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\TestOperText.txt");
            string[] aTestData = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return aTestData;
        }
        //====================用于生成服务代码

        public static string[] ReadInFields()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InFieldsText.txt");
            string[] arrayInFields = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayInFields;
        }
        public static string[] ReadInTitleFields()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InTitleFieldsText.txt");
            string[] arrayInTitleFields = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayInTitleFields;
        }
        public static string[] ReadOutFields()
        {
            string[] arrayOutFields;
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\OutFieldsText.txt");
            if (text == "MsgCode")
            {
                arrayOutFields = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            }
            else
            {
                arrayOutFields = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            }
            return arrayOutFields;
        }
        public static string[] ReadOutTitleFields()
        {
            string[] arrayOutTitleFields;
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\OutTitleFieldsText.txt");

            arrayOutTitleFields = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            
            return arrayOutTitleFields;
        }
        public static string[] ReadInType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InTypeText.txt");
            string[] arrayInType = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayInType;
        }
        public static string[] ReadInTitleType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InTitleTypeText.txt");
            string[] arrayInTitleType = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayInTitleType;
        }
       
        public static List<string> ReadAndTranInType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\InOracleTypeText.txt");
            string[] arrayInType = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            List<string> TanInTypelist = new List<string>();
            foreach (var item in arrayInType)
            {
                switch (item)
                {
                    case "VARCHAR2":
                        TanInTypelist.Add("string");
                        break;
                    case "DECIMAL":
                        TanInTypelist.Add("double");
                        break;
                    case "NUMBER":
                        TanInTypelist.Add("int");
                        break;
                    case "CHAR":
                        TanInTypelist.Add("char");
                        break;
                    case "DOUBLE":
                        TanInTypelist.Add("double");
                        break;
                    case "FLOAT":
                        TanInTypelist.Add("float");
                        break;
                }
            }
            return TanInTypelist;
        }
        public static string[] ReadOutType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\OutTypeText.txt");
            string[] arrayOutType = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayOutType;
        }

        public static string[] ReadOutTitleType()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\OutTitleTypeText.txt");
            string[] arrayOutTitleType = text.ToLower().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return arrayOutTitleType;
        }

        public static string[] ReadInFieldsForSQL()
        {
            string text = System.IO.File.ReadAllText(@"E:\vs2015_project\ODBCtest\ConTestODBC\bin\Debug\CreateServer\FieldsForSQLText.txt");
            string[] arrayInFieldsRow = text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            List<string> Fieldlist = new List<string>();
            List<string> Typelist = new List<string>();
            foreach (var item in arrayInFieldsRow)
            {
                string[] aFieldsDetail = item.Split(new string[] { " " }, StringSplitOptions.None);
                Fieldlist.Add(aFieldsDetail[1]);
                Typelist.Add(aFieldsDetail[3]);
            }
            return arrayInFieldsRow;
        }
    }
}
